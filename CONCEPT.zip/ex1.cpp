#include <iostream>
#include <type_traits>

int gcd(int a, int b)
{
    return 0;
}

int main()
{
    gcd(1, 2);
}